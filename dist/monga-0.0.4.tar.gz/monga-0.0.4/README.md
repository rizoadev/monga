# Monga

mongodb `pymongo` wrapper
